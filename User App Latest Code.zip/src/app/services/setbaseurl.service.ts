import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SetbaseurlService {
  // Set_base_url = 'http://localhost:58570/api/';
  Set_base_url = 'https://rightadmissionplus.com/api/';

  
  constructor() { }
}
