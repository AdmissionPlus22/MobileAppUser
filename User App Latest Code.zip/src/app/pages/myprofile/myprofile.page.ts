import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { RestApiService } from 'src/app/services/rest-api.service'
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';
import { SetbaseurlService } from 'src/app/services/setbaseurl.service';
import { Storage } from '@ionic/storage';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.page.html',
  styleUrls: ['./myprofile.page.scss'],
})
export class MyprofilePage implements OnInit {
  UserId: any
  Site_url: string
  MyProfileData: any={};
  FullName: any
  EmailId: any 
  Phone: any
  Location: any
  Password: any
  ReturnString: any

  constructor(public NavController: NavController,
    private router: Router,
    private baseurl: SetbaseurlService,
    public restApiService: RestApiService,
    public loadingController: LoadingController,
    private toastController: ToastController,
    private storage: Storage) {
      this.Site_url = this.baseurl.Set_base_url

      this.Initilize_DataIntoStorage()

    this.storage.get('UserId').then((val) => {
      console.log('UserId is', val);
      this.UserId = val
    });
   }
   async Initilize_DataIntoStorage() {
    const loading = await this.loadingController.create({
      message: 'Please wait',
      duration: 200
    });
    await loading.present();

    var dataToSend =
    { 
      "UserId": this.UserId
    };

    this.restApiService.GetMyProfileData(dataToSend).subscribe(dataReturnFromService => {
      console.log(dataReturnFromService)
      this.MyProfileData = dataReturnFromService

    })
    
    loading.dismiss();
  }

  async Save() {

    if ((this.FullName == '' || this.FullName == null) ||
      (this.Phone == '' || this.Phone == null) ||
      (this.Location == '' || this.Location == null) ||
      (this.Password == '' || this.Password == null)) {
      this.showError('Please enter the mandatory details')
    }
    else {

      const loading = await this.loadingController.create({
        message: 'Please wait',
        duration: 200
      });
      await loading.present();

      var dataToSend =
      {
        "UserId": this.UserId,
        "FullName": this.FullName,
        "EmailId": this.EmailId,
        "Phone": this.Phone,
        "Location": this.Location,
        "Password": this.Password
      };

      this.restApiService.UpdateUserProfile(dataToSend).subscribe(dataReturnFromService => {
        this.ReturnString = JSON.parse(JSON.stringify(dataReturnFromService))
        console.log(dataReturnFromService)
        if (dataReturnFromService == "Error") {
          this.showError('Ooops..! Something went wrong')
        }
        else {
          
          this.router.navigate(['/myprofile']);

          this.showError('Your profile updated successfully !')
        }
      })
    }

  }

  async showError(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
    });
    toast.present();
  }
  handleRefresh(event) {
    setTimeout(() => {
      this.Initilize_DataIntoStorage()
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  }
  async Home() {
    this.router.navigate(['/homemain']);
  }
  async MyProfile() {
    this.router.navigate(['/myprofile']);
  }
   
  ngOnInit() {
  }

}
