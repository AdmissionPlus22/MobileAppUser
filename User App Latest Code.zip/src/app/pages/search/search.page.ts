import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { RestApiService } from 'src/app/services/rest-api.service'
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';
import { SetbaseurlService } from 'src/app/services/setbaseurl.service';
import { Storage } from '@ionic/storage';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage implements OnInit {
  Site_url: string
  segment = 'second';
  InstituteName : string 
  Location: string
  SearchList: any
  UserId: any="";
  SchoolId: any="";
  CollegeId: any="";
  UniversityId: any="";
  ReturnString: any="";
  Latitude: any = ""
  Longitude: any = ""

  constructor(private router: Router,
    private baseurl: SetbaseurlService,
    private storage: Storage,
    public restApiService: RestApiService,
    private alertCtrl: AlertController,
    private http: HttpClient,
    public loadingController: LoadingController,
    private toastController: ToastController,
    private platform: Platform) { 
      this.Site_url = this.baseurl.Set_base_url
      this.Initilize_DataIntoStorage()

      this.platform.ready().then(() => {
        this.storage.get('Latitude').then((id) => {
          if (id) {
            this.Latitude = id
          }
          else {
            this.storage.get('Latitude').then((id) => {
              this.Latitude = id
            })
          }
        })
      })
      this.platform.ready().then(() => {
        this.storage.get('Longitude').then((id) => {
          if (id) {
            this.Longitude = id
          }
          else {
            this.storage.get('Longitude').then((id) => {
              this.Longitude = id
            })
          }
        })
      })
      
      this.storage.get('UserId').then((val) => {
        console.log('UserId is', val);
        this.UserId = val
      });
    }
    
    async Initilize_DataIntoStorage() {
      const loading = await this.loadingController.create({
        message: 'Please wait',
        duration: 300
      });
      await loading.present();
    }

    async Search() {

      const loading = await this.loadingController.create({
        message: 'Please wait',
        duration: 300
      });
      await loading.present();
      var dataToSend =
      {
        "InstituteName": this.InstituteName,
        "Location": this.Location,
        "Latitude": this.Latitude,
        "Longitude": this.Longitude      
      };
      this.restApiService.GetSearchData(dataToSend).subscribe(dataReturnFromService => {
        console.log(dataReturnFromService)
        this.SearchList = dataReturnFromService

      })     
      loading.dismiss();
  }

  async SchoolLike(id) {
    this.SchoolId = id
    this.Initilize_DataIntoStorage()

    var dataToSend =
    {
      "SchoolId": this.SchoolId,
      "UserId": this.UserId
    };

    this.restApiService.InsertSchoolLike(dataToSend).subscribe(dataReturnFromService => {
      this.ReturnString = JSON.parse(JSON.stringify(dataReturnFromService))
      console.log(dataReturnFromService)
      if (dataReturnFromService == "Not Submited") {
      }
      else {
        
        this.router.navigate(['/search']);
        this.showError('Thank You !')
      }
    })
    
  }
  async CollegeLike(id) {
    this.CollegeId = id
    this.Initilize_DataIntoStorage()

    var dataToSend =
    {
      "CollegeId": this.CollegeId,
      "UserId": this.UserId
    };

    this.restApiService.InsertCollegeLike(dataToSend).subscribe(dataReturnFromService => {
      this.ReturnString = JSON.parse(JSON.stringify(dataReturnFromService))
      console.log(dataReturnFromService)
      if (dataReturnFromService == "Not Submited") {
      }
      else {
        
        this.router.navigate(['/search']);
        this.showError('Thank You !')
      }
    })
    
  }

  async UnivesityLike(id) {
    this.UniversityId = id
    this.Initilize_DataIntoStorage()

    var dataToSend =
    {
      "UniversityId": this.UniversityId,
      "UserId": this.UserId
    };

    this.restApiService.InsertUniversityLike(dataToSend).subscribe(dataReturnFromService => {
      this.ReturnString = JSON.parse(JSON.stringify(dataReturnFromService))
      console.log(dataReturnFromService)
      if (dataReturnFromService == "Not Submited") {
      }
      else {
        
        this.router.navigate(['/search']);
        this.showError('Thank You !')
      }
    })
    
  }

  async showError(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
    });
    toast.present();
  }
  
  async SchoolDetail(id) {
    this.router.navigate(['/schooldetail/' + id]);
  }

  async CollegeDetail(id) {
    this.router.navigate(['/collegedetail/' + id]);
  }

  async UniversityDetail(id) {
    this.router.navigate(['/universitydetail/' + id]);
  }
  async SchoolComment(id) {
    this.router.navigate(['/schoolcomment/' + id]);
  }
  async CollegeComment(id) {
    this.router.navigate(['/collegecomment/' + id]);
  }
  async UniversityComment(id) {
    this.router.navigate(['/universitycomment/' + id]);
  }
  async Home() {
    this.router.navigate(['/homemain']);
  }
  async MyProfile() {
    this.router.navigate(['/myprofile']);
  }
  handleRefresh(event) {
    setTimeout(() => {
      this.Search();
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  }
  ngOnInit() {
  }

}
