import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institutiondetails',
  templateUrl: './institutiondetails.page.html',
  styleUrls: ['./institutiondetails.page.scss'],
})
export class InstitutiondetailsPage implements OnInit {

  // Segment Active
  segment = 'first';

  constructor() { }

  ngOnInit() {
  }

}
