import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { RestApiService } from 'src/app/services/rest-api.service'
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';
import { SetbaseurlService } from 'src/app/services/setbaseurl.service';
import { Storage } from '@ionic/storage';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-homemain',
  templateUrl: './homemain.page.html',
  styleUrls: ['./homemain.page.scss'],
})
export class HomemainPage implements OnInit {
  Site_url: string
  UserId: any="";
  OTP: any="";

  SchoolBannerList: any = "";
  $scope: any="";

  constructor(private router: Router,
    private baseurl: SetbaseurlService,
    private storage: Storage,
    public restApiService: RestApiService,
    private alertCtrl: AlertController,
    private http: HttpClient,
    public loadingController: LoadingController,
    private toastController: ToastController,
    private platform: Platform) { 
    this.Site_url = this.baseurl.Set_base_url
    this.Initilize_DataIntoStorage()

    this.storage.get('OTP').then((val) => {
      console.log('OTP is', val);
      this.OTP = val
    });

    this.storage.get('UserId').then((val) => {
      console.log('UserId is', val);
      this.UserId = val
    });
  }

  async Initilize_DataIntoStorage() {
    const loading = await this.loadingController.create({
      message: 'Please wait',
      duration: 7000
    });
    await loading.present();

    this.http.get(this.Site_url + 'SchoolBannerApi').subscribe(data => {
      this.SchoolBannerList = data
      console.log('SchoolBanner List' + this.SchoolBannerList)
     
    })
    loading.dismiss();
  }
     

  async redirectTonext() {
    this.router.navigate(['/searchinstitutionlist']);
  }

  async SchoolList() {
    this.router.navigate(['/schoollist']);
  }

  async CollegeList() {
    this.router.navigate(['/collegelist']);
  }

  async UniversityList() {
    this.router.navigate(['/universitylist']);
  }
  async TutorList() {
    this.router.navigate(['/tutorlist']);
  }
  async VendorList() {
    this.router.navigate(['/vendorlist']);
  }
  async Detail(id) {
    this.router.navigate(['/schooldetail/' + id]);
  }
 async Search() {
    this.router.navigate(['/search']);
  }
  async Home() {
    this.router.navigate(['/homemain']);
  }
  async MyProfile() {
    this.router.navigate(['/myprofile']);
  }
  LogoutUser() {
    localStorage.removeItem(this.OTP)
    this.router.navigate(['/login']);
    this.showError('Logout Successfully')
  }

  async showError(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
    });
    toast.present();
  }

  handleRefresh(event) {
    setTimeout(() => {
      this.Initilize_DataIntoStorage();
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  }

  slidesDidLoad(slides) {
    slides.startAutoplay();
  }
  
  CallTel = function(tel) {
    window.location.href = 'tel:'+ tel;
}
  ngOnInit() {
    
  }

}
