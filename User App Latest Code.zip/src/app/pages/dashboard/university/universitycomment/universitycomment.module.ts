import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UniversitycommentPageRoutingModule } from './universitycomment-routing.module';

import { UniversitycommentPage } from './universitycomment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UniversitycommentPageRoutingModule
  ],
  declarations: [UniversitycommentPage]
})
export class UniversitycommentPageModule {}
