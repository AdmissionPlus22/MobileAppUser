import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UniversitycommentPage } from './universitycomment.page';

const routes: Routes = [
  {
    path: '',
    component: UniversitycommentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UniversitycommentPageRoutingModule {}
