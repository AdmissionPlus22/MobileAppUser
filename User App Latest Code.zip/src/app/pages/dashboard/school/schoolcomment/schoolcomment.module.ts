import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SchoolcommentPageRoutingModule } from './schoolcomment-routing.module';

import { SchoolcommentPage } from './schoolcomment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SchoolcommentPageRoutingModule
  ],
  declarations: [SchoolcommentPage]
})
export class SchoolcommentPageModule {}
