import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { RestApiService } from 'src/app/services/rest-api.service'
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';
import { SetbaseurlService } from 'src/app/services/setbaseurl.service';
import { Storage } from '@ionic/storage';
import { Platform } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-schoolcomment',
  templateUrl: './schoolcomment.page.html',
  styleUrls: ['./schoolcomment.page.scss'],
})
export class SchoolcommentPage implements OnInit {
  Site_url: string
  SchoolId: string
  UserId: any="";
  Comment: any="";
  ReturnString: any

  constructor(private router: Router,
    private baseurl: SetbaseurlService,
    private storage: Storage,
    public restApiService: RestApiService,
    private alertCtrl: AlertController,
    private http: HttpClient,
    public loadingController: LoadingController,
    private toastController: ToastController,
    private platform: Platform,
    private activatedRoute: ActivatedRoute) {
    this.Site_url = this.baseurl.Set_base_url
    this.SchoolId = this.activatedRoute.snapshot.paramMap.get('myid');

    this.Initilize_DataIntoStorage()

    this.storage.get('UserId').then((val) => {
      console.log('UserId is', val);
      this.UserId = val
    });
  }

  async Initilize_DataIntoStorage() {
    const loading = await this.loadingController.create({
      message: 'Please wait',
      duration: 200
    });
    await loading.present();

  }

  async Save() {

    if ((this.Comment == '' || this.Comment == null)) {
      this.showError('Please enter the mandatory details')
    }
    else {

      const loading = await this.loadingController.create({
        message: 'Please wait',
        duration: 700
      });
      await loading.present();
      var dataToSend =
      {
        "Comment": this.Comment,
        "SchoolId": this.SchoolId,
        "UserId": this.UserId
      };

      this.restApiService.InsertSchoolComment(dataToSend).subscribe(dataReturnFromService => {
        this.ReturnString = JSON.parse(JSON.stringify(dataReturnFromService))
        console.log(dataReturnFromService)
        if (dataReturnFromService == "Not Submitted") {
          this.showError('Ooops..! Something went wrong')
        }
        else {
          
          this.router.navigate(['/schoollist']);

          this.showError('Thank You !')
        }
      })
    }

  }

  async showError(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
    });
    toast.present();
  }
  async Home() {
    this.router.navigate(['/homemain']);
  }
  async MyProfile() {
    this.router.navigate(['/myprofile']);
  }
  ngOnInit() {
  }

}
