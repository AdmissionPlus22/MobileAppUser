import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SchoolcommentPage } from './schoolcomment.page';

const routes: Routes = [
  {
    path: '',
    component: SchoolcommentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SchoolcommentPageRoutingModule {}
