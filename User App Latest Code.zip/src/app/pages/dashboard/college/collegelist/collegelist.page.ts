import { Component, OnInit, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { RestApiService } from 'src/app/services/rest-api.service'
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ToastController } from '@ionic/angular';
import { SetbaseurlService } from 'src/app/services/setbaseurl.service';
import { Storage } from '@ionic/storage';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-collegelist',
  templateUrl: './collegelist.page.html',
  styleUrls: ['./collegelist.page.scss'],
})
export class CollegelistPage implements OnInit {
  Site_url: string
  CollegeList: any
  Latitude: any = ""
  Longitude: any = ""
  Distance: any = 20
  CollegeId: any="";
  UserId: any="";
  ReturnString: any="";

  constructor(private router: Router,
    private baseurl: SetbaseurlService,
    private storage: Storage,
    public restApiService: RestApiService,
    private alertCtrl: AlertController,
    private http: HttpClient,
    public loadingController: LoadingController,
    private toastController: ToastController,
    private platform: Platform) {
    this.Site_url = this.baseurl.Set_base_url
    this.Initilize_DataIntoStorage()

    this.platform.ready().then(() => {
      this.storage.get('Latitude').then((id) => {
        if (id) {
          this.Latitude = id
        }
        else {
          this.storage.get('Latitude').then((id) => {
            this.Latitude = id
          })
        }
      })
    })

    this.platform.ready().then(() => {
      this.storage.get('Longitude').then((id) => {
        if (id) {
          this.Longitude = id
        }
        else {
          this.storage.get('Longitude').then((id) => {
            this.Longitude = id
          })
        }
      })
    })
    this.storage.get('UserId').then((val) => {
      console.log('UserId is', val);
      this.UserId = val
    });
  }

  async Initilize_DataIntoStorage() {
    const loading = await this.loadingController.create({
      message: 'Please wait',
      duration: 7000
    });
    await loading.present();
    var dataToSend =
    {
      "Latitude": this.Latitude,
      "Longitude": this.Longitude,
      "Distance": this.Distance
    };

    this.restApiService.GetCollegeData(dataToSend).subscribe(dataReturnFromService => {
      console.log(dataReturnFromService)
      this.CollegeList = dataReturnFromService

    })
    loading.dismiss();
  }
  async Like(id) {
    this.CollegeId = id
    this.Initilize_DataIntoStorage()

    var dataToSend =
    {
      "CollegeId": this.CollegeId,
      "UserId": this.UserId
    };

    this.restApiService.InsertCollegeLike(dataToSend).subscribe(dataReturnFromService => {
      this.ReturnString = JSON.parse(JSON.stringify(dataReturnFromService))
      console.log(dataReturnFromService)
      if (dataReturnFromService == "Not Submited") {
      }
      else {
        
        this.router.navigate(['/collegelist']);
        this.showError('Thank You !')
      }
    })
    
  }

  async showError(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
    });
    toast.present();
  }


  async GetDropdowndata($event) {
    var a = $event.target.value
    this.Distance = a
    this.Initilize_DataIntoStorage()
  }

  handleRefresh(event) {
    setTimeout(() => {
      this.Initilize_DataIntoStorage();
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  }

  async Detail(id) {
    this.router.navigate(['/collegedetail/' + id]);
  }
  async Comment(id) {
    this.router.navigate(['/collegecomment/' + id]);
  }
  async Home() {
    this.router.navigate(['/homemain']);
  }
  async MyProfile() {
    this.router.navigate(['/myprofile']);
  }
  ngOnInit() {


  }

}
