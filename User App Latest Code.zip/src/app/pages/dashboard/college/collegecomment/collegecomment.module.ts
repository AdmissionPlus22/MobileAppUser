import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CollegecommentPageRoutingModule } from './collegecomment-routing.module';

import { CollegecommentPage } from './collegecomment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CollegecommentPageRoutingModule
  ],
  declarations: [CollegecommentPage]
})
export class CollegecommentPageModule {}
